PageMirror Single HTML Snapshot

This package contains a single rendered HTML file.

Important:
- Assets such as images, CSS, JavaScript, fonts, and media are still loaded from the original website URLs.
- This snapshot is not fully offline-ready.
- If the original website changes or removes assets, this HTML file may change visually or stop loading some resources.
- This mode is useful for quick visual snapshots and animation-heavy pages.

Files included:
- single.html: The captured page with remote asset references
- metadata.json: Snapshot metadata and job information
- screenshot.png: Full-page screenshot (if available)
- README_REMOTE_ASSETS.txt: This file
